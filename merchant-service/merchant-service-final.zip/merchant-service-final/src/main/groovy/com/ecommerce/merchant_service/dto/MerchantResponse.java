package com.ecommerce.merchant_service.dto;

import lombok.Data;

import java.math.BigDecimal;

@Data
public class MerchantResponse {
    private Long merchantId;
    private Long userId;
    private String name;
    private String email;
    private String role;
    private BigDecimal rating;
}
